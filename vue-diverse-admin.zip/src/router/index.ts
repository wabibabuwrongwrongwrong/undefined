import { createRouter, createWebHistory } from 'vue-router'
import { useTokenStore } from '@/stores/mytoken'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () =>import('@/components/layout/AppLayout.vue'),
      meta: { requiresAuth: true },
      children: [
        { path: '', name: 'index', component: () => import('@/views/IndexView.vue') },
        { path: 'about', name: 'about', component: () => import('@/views/IndexView.vue') },
        { path: '/:xxx(.*)*', name: 'ErrorPage', component: () => import('@/components/layout/ErrorPage.vue') }
      ]
    },

    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/login/LoginView.vue')
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.matched.some(r => r.meta?.requiresAuth)) {
    const store = useTokenStore()
    if (!store.token?.access) {
      next({ name: 'login',query: { redirect: to.fullPath } })
    }
  }
  next()
})

export default router
