<script setup lang="ts">

</script>

<template>
<el-radio-group v-model="size">
    <el-radio value="large">Large</el-radio>
    <el-radio value="default">Default</el-radio>
    <el-radio value="small">Small</el-radio>
  </el-radio-group>
</template>

<style scoped lang="scss">

</style>