<script setup lang="ts">

</script>

<template>
<h1>默认首页</h1>
</template>

<style scoped lang="scss">

</style>