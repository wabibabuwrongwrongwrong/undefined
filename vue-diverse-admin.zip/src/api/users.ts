import request from '@/utils/request'
import { useTokenStore } from '@/stores/mytoken'


type Response = {
  content: JSON,
  message: string,
  state: number,
  success: boolean
}

type LoginInfo = {
  username: string,
  password: string,
}
//获取token
export const login = (loginInfo: LoginInfo): Promise<Response> => {
  return request.post<Response>('/token/', loginInfo)
    .then(response => response.data)
    .catch(error => {
      console.log("token获取失败",error)
      throw error
    })
}
//验证token
export const verifyToken = (): Promise<Response> => {
  return request.post<Response>('/token/verify/', {token:useTokenStore().token?.access})
    .then(response => response.data)
    .catch(error => {
      console.log("token验证失败",error)
      throw error
    })
}

//刷新token
export const refreshToken = (): Promise<Response> => {
  return request.post<Response>('/token/refresh/', {refresh:useTokenStore().token?.refresh})
    .then(response => response.data)
    .catch(error => {
      console.log("token刷新失败",error)
      throw error
    })
}


// 获取用户详细信息
const getUserIdFromToken = (token: string): string | null => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]))
    return payload.user_id || null
  } catch (e) {
    return null
  }
}

export const getInfo = async (): Promise<Response> => {
  const store = useTokenStore()
  const token = store.token?.access

  const userId = getUserIdFromToken(token)
  if (!userId) {
    throw new Error('Invalid token: unable to extract user_id')
  }

  return request.get<Response>(`/api/v1/users/${userId}`)
    .then(response => response.data)
    .catch(error => {
      throw error
    })
}