<script setup lang="ts">

</script>

<template>
<h1>报错页面</h1>
</template>

<style scoped lang="scss">

</style>