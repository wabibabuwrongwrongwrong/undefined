import axios from 'axios'
import { useTokenStore } from '@/stores/mytoken'
import { refreshToken } from '@/api/users'
import router from '@/router'

// 创建 axios 实例
const request = axios.create({
  // baseURL: 'http://47.102.20.196:8000/'
  baseURL: 'http://localhost:8000/'
})

// 请求拦截器
request.interceptors.request.use((config) => {
  // 确保 config.headers 存在
  if (!config.headers) {
    config.headers = new axios.AxiosHeaders()
  }

  // 获取 token store
  const store = useTokenStore()

  // store.token 存在，则设置Authorization头
  if (store.token.access) {
    config.headers.Authorization = `Bearer ${store.token.access}`
  }
  return config
}, (error) => {
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 响应拦截器
request.interceptors.response.use((response) => response, async (error) => {
  if (error.response.status === 401) {
    refreshToken()
      .then(res => {
        useTokenStore().saveToken(res.content)
        // 返回重新发送的请求
        return request(error.config)
      })
      .catch(error => {
        console.error('刷新 token 失败', error)
        // 如果刷新 token 失败，跳转到登录页面
        router.push({ name: 'login' })
      })
  }
  return Promise.reject(error)
})

export default request
